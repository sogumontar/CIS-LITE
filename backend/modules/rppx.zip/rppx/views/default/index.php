<div class="">
    <?php 
    $d=date("D , d  M  Y");
        // $date=date("D/M/Y");
    ?>
    <p><?php echo $d."<br><br>"; ?></p>
    <div class="container">
        <div class="col-md-7">
            <h2>Request From ...............</h2>
        </div>
        <div class="col-md-2" >
            <br>
            Date:....<br><br><br>
        </div>
        <
    </div>
    <div class="container">
        <div class="col-md-12">
            <table >
                <tr>
                    <td width="150px" align="center">Nama Mata Kuliah<br><br>  </td>
                    <td width="150px" align="center">Jumlah SKS<br><br></td>
                    <td width="150px" align="center">Kode MK<br><br></td>
                    <td width="150px" align="center">Dosen <br><br></td>
                </tr>
                <tr>
                    <td width="150px" align="center">Alsrudat</td>
                    <td width="150px" align="center">3</td>
                    <td width="150px" align="center">IF41ALS</td>
                    <td width="150px" align="center">Teamsar</td>
                </tr>
                <tr>
                    <td width="150px" align="right" style="margin-left: 250px;" colspan="3"></td>
                    <td align="center"><br> <button class="btn btn-primary">Submit</button></td>
                </tr>
            </table>
        </div>
    </div>
</div>
