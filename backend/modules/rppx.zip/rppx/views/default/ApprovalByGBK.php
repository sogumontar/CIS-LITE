<div class="rppx-default-index">
    <?php 
    $d=date("D , d  M  Y");
        // $date=date("D/M/Y");
    ?>
    <p><?php echo $d."<br><br>"; ?></p>
    <div class="container">
        <div class="col-md-7">
            <h2>Request From ...............</h2>
        </div>
        <div class="col-md-2" >
            <br>
            Date:....<br><br><br>
        </div>
        <
    </div>
    <div class="container">
        <div class="col-md-12">
            <table >
                <tr>
                    <td width="150px" align="center">Nama Dosen  <br><br>  </td>
                    <td width="150px" align="center">NIP <br><br></td>
                    <td width="150px" align="center">Mata Kuliah <br><br></td>
                    <td width="150px" align="center">Date <br><br></td>
                </tr>
                <tr>
                    <td width="150px" align="center">RoyDed</td>
                    <td width="150px" align="center">11417010</td>
                    <td width="150px" align="center">PBO</td>
                    <td width="150px" align="center">12/12/12</td>
                </tr>
                <tr>
                    <td width="150px" align="right" style="margin-left: 250px;" colspan="3"></td>
                    <td align="center"><br> <button class="btn btn-primary">Approve</button></td>
                </tr>
            </table>
        </div>
    </div>
</div>
