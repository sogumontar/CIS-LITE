<?php
	use yii\helpers\Html;

	$this->title = 'Approval Dekan';
	$this->params['breadcrumbs'][] = $this->title;
	$this->params['layout'] = 'full';
?>

<div class="Penugasan-pengajaran-approval-dekan">
	
	<div class="container-fluid">
		<div class="row" style="margin-top: 10px">
			<div class="col">
				<p>Kamis, 4 april 2019</p>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<h1><?= Html::encode($this->title) ?></h1>
			</div>
			<div class="col-2">
				<p>Date : 20/02/2019</p>
			</div>
		</div>
	</div>

</div>