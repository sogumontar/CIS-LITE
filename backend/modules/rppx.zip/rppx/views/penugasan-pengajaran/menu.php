<?php
    use yii\helpers\Url;
    use backend\modules\rppx\models\AdakPengajaran;
    use backend\modules\rppx\models\Kuliah;
    use backend\modules\rppx\models\Kelas;

    $this->title = 'Menu';
$this->params['breadcrumbs'][] = $this->title;
$this->params['layout'] = 'full';
$kel=$_GET['kelas'];
$tkt=Kelas::find()->where(['nama' => $kel])->all();
$tt;
foreach ($tkt as $key) {
    $tt=$key['ta'];
    if($key['nama']==$_GET['kelas']){
         $key['nama'];
    }
}
echo $tt;
$matkul=Kuliah::find()->where('tipe='.$tt)->all();

?>

<div class="penugasan-pengajarann-menu">
    <?php 
    $d=date("D , d  M  Y");
        // $date=date("D/M/Y");
    ?>
    <p><?php echo $d."<br><br>"; 

    $prod;
    ?></p>

      
    <?php
    if(date('m')>5){
        ?>
          <button class="btn btn-primary" disabled="">Semester Ganjil</button>
          <button class="btn btn-primary">Semester Genap</button>
        <br><br><br>
        <?php 
        foreach ($matkul as $key ) {
            if($key['sem']%2==0){
                ?>
                  <div class="container">
                    <div class="col-md-5">

                        <h3><?php echo $key['nama_kul_ind'];?></h3>
                    </div>
                    <div class="col-md-3" align="right">
                        <a href="<?=Url::toRoute(['/rppx/penugasan-pengajaran/create','semester'=>$key['sem'],'kelas'=>$_GET['kelas'],'kuliah'=>$key['kuliah_id']]) ?>" class="btn btn-primary">Edit</a>
                        
                    </div>
                </div>
                <hr>
                <?php  
            }
            
        }
    }else{
          ?>
          <button class="btn btn-primary" >Semester Ganjil</button>
          <button class="btn btn-primary" disabled="">Semester Genap</button>
        <br><br><br>
        <?php 
        foreach ($matkul as $key ) {
            if($key['sem']%2!=0){
              ?>
                  <div class="container">
                    <div class="col-md-5">

                        <h3><?php echo $key['nama_kul_ind'];?></h3>
                    </div>
                    <div class="col-md-3" align="right">
                        <a href="<?=Url::toRoute(['/rppx/penugasan-pengajaran/create','semester'=>$key['sem'],'kelas'=>$_GET['kelas']]) ?>" class="btn btn-primary">Edit</a>
                        
                    </div>
                </div>
                <hr>
                <?php  
            }
            
        }
    }
   
    ?>
    
</div>
